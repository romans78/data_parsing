import scrapy
from scrapy.http import HtmlResponse
from jobparser.items import JobparserItem


class SjruSpider(scrapy.Spider):
    name = 'sjru'
    allowed_domains = ['superjob.ru']
    start_urls = ['https://www.superjob.ru/vacancy/search/?keywords=python&geo%5Bt%5D%5B0%5D=4&page=1',
                  'https://spb.superjob.ru/vacancy/search/?keywords=python&page=1']
    link = None

    def parse(self, response: HtmlResponse):
        next_page_number = str(int(response.url.split('=')[-1]) + 1)
        next_page = response.url.split('=')
        next_page[-1] = next_page_number
        next_page = '='.join(next_page)
        if not response.xpath("//span[@class='_3ZG_V _1_rZy dXrZh _2ogzo']").get():
            yield response.follow(next_page, callback=self.parse)
        links = response.xpath("//a[contains(@class,'icMQ_ _6AfZ9')]/@href").getall()
        for link in links:
            yield response.follow(link, callback=self.vacancy_parse)

    def vacancy_parse(self, response: HtmlResponse):
        name = response.xpath("//h1[@class='rFbjy _3ZG_V _1_rZy Ml4Nx']/text()").get()
        salary = response.xpath("//span[@class='_2Wp8I _185V- _1_rZy Ml4Nx']/text()").getall()
        _id = response.url.split('/')[-1].split('-')[-1].split('.')[0]
        link = response.url
        item = JobparserItem(name=name, salary=salary, link=link, _id=_id)

        yield item
