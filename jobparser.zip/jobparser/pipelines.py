# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError as dke


class JobparserPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_base = client['vacancies']

    def process_item(self, item, spider):
        item['salary_min'], item['salary_max'], item['currency'] = self.process_salary(item['salary'], spider.name)
        del item['salary']
        collection = self.mongo_base[spider.name]
        try:
            collection.insert_one(item)
        except dke:
            print(f"Попытка ввода уже существующей записи с id {item['_id']}")
        return item

    def process_salary(self, salary, spider_name):
        if spider_name == 'hhru':
            if not salary:
                return None, None, None
            else:
                for i in range(len(salary)):
                    salary[i] = salary[i].replace('\xa0', '')
                    salary[i] = salary[i].strip()
                salary_min = None
                salary_max = None
                currency = None
                if "указана" not in salary[0]:
                    salary_min = float(salary[1]) if 'от' in salary else None
                    salary_max = float(salary[1]) if 'до' in salary[0] else float(salary[3]) if 'до' in salary[
                        2] else None
                    currency = salary[-2]
        if spider_name == 'sjru':
            if not salary or len(salary) == 1:
                return None, None, None
            else:
                if 'от' in salary or 'до' in salary:
                    amount_cur = salary[2]
                    amount_cur = amount_cur.split('\xa0')
                    currency = amount_cur[-1]
                    if len(amount_cur) == 3:
                        amount = amount_cur[0] + amount_cur[1]
                    if len(amount_cur) == 2:
                        amount = amount_cur[0]
                    salary[2] = amount
                    salary.append(currency)
                for i in range(len(salary)):
                    salary[i] = salary[i].replace('\xa0', '')
                    salary[i] = salary[i].strip()
                salary_min = None
                salary_max = None
                currency = None
                if 'от' in salary or 'до' in salary:
                    salary_min = float(salary[2]) if 'от' in salary else None
                    salary_max = float(salary[2]) if 'до' in salary else None
                else:
                    salary_min = float(salary[0])
                    salary_max = float(salary[1])
                currency = salary[-1]

        return salary_min, salary_max, currency
